package uz.demo.payment;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class PaymentService {
    private final ConcurrentHashMap<String, Payment> payments = new ConcurrentHashMap<>();

    public Payment create(BigDecimal amount, String currency, String description) {
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("amount 0 dan katta bo'lishi kerak");
        }
        if (currency == null || currency.isBlank()) {
            throw new IllegalArgumentException("currency kiritilishi kerak");
        }

        Payment payment = new Payment(amount, currency.toUpperCase(), description == null ? "" : description);
        payments.put(payment.getId(), payment);
        return payment;
    }

    public Optional<Payment> findById(String id) {
        return Optional.ofNullable(payments.get(id));
    }

    public List<Payment> findAll() {
        return payments.values().stream().toList();
    }

    public Payment pay(String id) {
        Payment payment = getExisting(id);
        synchronized (payment) {
            if (payment.getStatus() == PaymentStatus.CANCELLED) {
                throw new IllegalStateException("Bekor qilingan to'lovni to'lab bo'lmaydi");
            }
            if (payment.getStatus() == PaymentStatus.PAID) {
                return payment;
            }
            // Demo: real karta/bank provayderi o'rniga to'lov shu yerda muvaffaqiyatli deb belgilanadi.
            payment.setStatus(PaymentStatus.PAID);
            return payment;
        }
    }

    public Payment cancel(String id) {
        Payment payment = getExisting(id);
        synchronized (payment) {
            if (payment.getStatus() == PaymentStatus.PAID) {
                throw new IllegalStateException("To'langan to'lovni bekor qilib bo'lmaydi");
            }
            payment.setStatus(PaymentStatus.CANCELLED);
            return payment;
        }
    }

    private Payment getExisting(String id) {
        Payment payment = payments.get(id);
        if (payment == null) {
            throw new IllegalArgumentException("To'lov topilmadi: " + id);
        }
        return payment;
    }
}
