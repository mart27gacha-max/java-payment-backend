package uz.demo.payment;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.concurrent.Executors;

public class PaymentApplication {
    private static final PaymentService service = new PaymentService();

    public static void main(String[] args) throws Exception {
        int port = 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/payments", PaymentApplication::handlePayments);
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        System.out.println("Payment API ishga tushdi: http://localhost:" + port);
    }

    private static void handlePayments(HttpExchange exchange) throws IOException {
        try {
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            String[] parts = Arrays.stream(path.split("/"))
                    .filter(s -> !s.isBlank()).toArray(String[]::new);

            if (parts.length == 1 && method.equals("GET")) {
                send(exchange, 200, JsonUtil.payments(service.findAll()));
                return;
            }

            if (parts.length == 1 && method.equals("POST")) {
                String body = readBody(exchange);
                BigDecimal amount = JsonUtil.decimalField(body, "amount");
                String currency = JsonUtil.field(body, "currency");
                String description = JsonUtil.field(body, "description");
                Payment payment = service.create(amount, currency, description);
                send(exchange, 201, JsonUtil.payment(payment));
                return;
            }

            if (parts.length == 2 && method.equals("GET")) {
                service.findById(parts[1])
                        .ifPresentOrElse(p -> sendQuiet(exchange, 200, JsonUtil.payment(p)),
                                () -> sendQuiet(exchange, 404, JsonUtil.error("To'lov topilmadi")));
                return;
            }

            if (parts.length == 3 && method.equals("POST") && parts[2].equals("pay")) {
                send(exchange, 200, JsonUtil.payment(service.pay(parts[1])));
                return;
            }

            if (parts.length == 3 && method.equals("POST") && parts[2].equals("cancel")) {
                send(exchange, 200, JsonUtil.payment(service.cancel(parts[1])));
                return;
            }

            send(exchange, 404, JsonUtil.error("Endpoint topilmadi"));
        } catch (NumberFormatException e) {
            send(exchange, 400, JsonUtil.error("amount noto'g'ri formatda"));
        } catch (IllegalArgumentException e) {
            send(exchange, 400, JsonUtil.error(e.getMessage()));
        } catch (IllegalStateException e) {
            send(exchange, 409, JsonUtil.error(e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            send(exchange, 500, JsonUtil.error("Server xatosi"));
        }
    }

    private static String readBody(HttpExchange exchange) throws IOException {
        try (InputStream in = exchange.getRequestBody()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static void send(HttpExchange exchange, int status, String body) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(status, bytes.length);
        try (var out = exchange.getResponseBody()) {
            out.write(bytes);
        }
    }

    private static void sendQuiet(HttpExchange exchange, int status, String body) {
        try { send(exchange, status, body); } catch (IOException ignored) { }
    }
}
