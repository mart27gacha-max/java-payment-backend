package uz.demo.payment;

public enum PaymentStatus {
    CREATED,
    PAID,
    CANCELLED
}
