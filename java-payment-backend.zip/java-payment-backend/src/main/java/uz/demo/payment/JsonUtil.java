package uz.demo.payment;

import java.math.BigDecimal;
import java.util.List;

public final class JsonUtil {
    private JsonUtil() {}

    public static String payment(Payment p) {
        return "{" +
                "\"id\":\"" + esc(p.getId()) + "\"," +
                "\"amount\":" + p.getAmount().toPlainString() + "," +
                "\"currency\":\"" + esc(p.getCurrency()) + "\"," +
                "\"description\":\"" + esc(p.getDescription()) + "\"," +
                "\"status\":\"" + p.getStatus() + "\"," +
                "\"createdAt\":\"" + p.getCreatedAt() + "\"" +
                "}";
    }

    public static String payments(List<Payment> list) {
        return "[" + list.stream().map(JsonUtil::payment).reduce((a, b) -> a + "," + b).orElse("") + "]";
    }

    public static String error(String message) {
        return "{\"error\":\"" + esc(message) + "\"}";
    }

    public static String field(String json, String key) {
        String marker = "\"" + key + "\"";
        int keyPos = json.indexOf(marker);
        if (keyPos < 0) return null;
        int colon = json.indexOf(':', keyPos + marker.length());
        if (colon < 0) return null;
        int pos = colon + 1;
        while (pos < json.length() && Character.isWhitespace(json.charAt(pos))) pos++;

        if (pos < json.length() && json.charAt(pos) == '\"') {
            StringBuilder sb = new StringBuilder();
            boolean escaped = false;
            for (int i = pos + 1; i < json.length(); i++) {
                char c = json.charAt(i);
                if (escaped) { sb.append(c); escaped = false; continue; }
                if (c == '\\') { escaped = true; continue; }
                if (c == '\"') return sb.toString();
                sb.append(c);
            }
            return null;
        }

        int end = pos;
        while (end < json.length() && ",}".indexOf(json.charAt(end)) == -1) end++;
        return json.substring(pos, end).trim();
    }

    public static BigDecimal decimalField(String json, String key) {
        String value = field(json, key);
        return value == null || value.isBlank() ? null : new BigDecimal(value);
    }

    private static String esc(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r");
    }
}
