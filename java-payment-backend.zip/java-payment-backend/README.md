# Oddiy Java Payment Backend

Spring Boot ishlatilmagan. Faqat Java 17 standard `HttpServer` va in-memory storage ishlatiladi.

## Ishga tushirish

```bash
mvn clean compile
mvn exec:java
```

Server: `http://localhost:8080`

## API

### To'lov yaratish
```bash
curl -X POST http://localhost:8080/payments \
  -H "Content-Type: application/json" \
  -d '{"amount":150000,"currency":"UZS","description":"Telefon uchun tolov"}'
```

### Barcha to'lovlar
```bash
curl http://localhost:8080/payments
```

### Bitta to'lov
```bash
curl http://localhost:8080/payments/{id}
```

### To'lovni amalga oshirish (demo)
```bash
curl -X POST http://localhost:8080/payments/{id}/pay
```

### Bekor qilish
```bash
curl -X POST http://localhost:8080/payments/{id}/cancel
```

## Statuslar

- `CREATED` — yangi to'lov
- `PAID` — to'langan
- `CANCELLED` — bekor qilingan

## Muhim

Bu o'quv/demo loyiha. Haqiqiy karta ma'lumotlari saqlanmaydi, bank/Click/Payme integratsiyasi yo'q, authentication va database mavjud emas.
